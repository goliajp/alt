import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import ts from 'typescript';

const root = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
rmSync(join(root, 'lib'), { recursive: true, force: true });
execFileSync(process.execPath, [require.resolve('typescript/bin/tsc'), '-p', join(root, 'tsconfig.build.json')], { stdio: 'inherit' });
// Node ESM needs explicit extensions. Keep canonical component sources intact
// and resolve relative emitted imports in both JavaScript and declarations.
for (const name of readdirSync(join(root, 'lib'))) {
  const path = join(root, 'lib', name), source = readFileSync(path, 'utf8');
  const ast = ts.createSourceFile(name, source, ts.ScriptTarget.Latest, true);
  const edits = [];
  function visit(node) {
    if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier) {
      const specifier = node.moduleSpecifier;
      if (specifier.text.startsWith('./') && !/\.[a-z]+$/.test(specifier.text))
        edits.push([specifier.getEnd() - 1, '.js']);
    }
    ts.forEachChild(node, visit);
  }
  visit(ast);
  let result = source;
  for (const [offset, text] of edits.sort((a, b) => b[0] - a[0])) result = result.slice(0, offset) + text + result.slice(offset);
  writeFileSync(path, result);
}
