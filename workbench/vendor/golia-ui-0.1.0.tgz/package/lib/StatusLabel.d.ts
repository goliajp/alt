import type { HTMLAttributes, ReactNode } from 'react';
/** One centered text box for status marks, legends and short inline labels. */
export declare function StatusLabel({ marker, children, truncate, className, ...props }: HTMLAttributes<HTMLSpanElement> & {
    marker?: ReactNode;
    truncate?: boolean;
}): import("react").JSX.Element;
