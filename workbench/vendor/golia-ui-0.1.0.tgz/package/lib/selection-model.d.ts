import type { ReactNode } from "react";
export type SelectionOption = {
    value: string;
    label: string;
    lang?: string;
    description?: string;
    group?: string;
    keywords?: readonly string[];
    disabled?: boolean;
    icon?: ReactNode;
};
export type SelectionOptionInput = SelectionOption | readonly [string, string];
export type OptionLoader = (query: string, context: {
    signal: AbortSignal;
}) => Promise<readonly SelectionOption[]>;
export declare function selectionOptions(options: readonly SelectionOptionInput[]): SelectionOption[];
export declare function normalizeSearch(value: string): string;
export declare function filterOptions(options: readonly SelectionOption[], query: string): SelectionOption[];
export declare function mergeOptions(...lists: readonly (readonly SelectionOption[])[]): SelectionOption[];
export declare function toggleSelection(values: readonly string[], value: string): string[];
