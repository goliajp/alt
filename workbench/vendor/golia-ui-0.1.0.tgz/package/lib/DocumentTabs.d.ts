type Entry = {
    key: string;
    title: string;
};
export declare function DocumentTabs({ entries, active, select, close, closeMany, reorder, labels, locale }: {
    locale: 'en' | 'zh' | 'ja';
    closeMany: (keys: string[]) => void;
    entries: Entry[];
    active: string;
    select: (key: string) => void;
    close: (key: string) => void;
    reorder: (key: string, index: number) => void;
    labels: {
        navigation: string;
        hint: string;
        close: (name: string) => string;
        moved: (name: string, position: number, total: number) => string;
    };
}): import("react").JSX.Element;
export {};
