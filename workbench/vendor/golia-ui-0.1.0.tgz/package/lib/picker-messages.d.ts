export declare const pickerMessages: {
    readonly "selection.requiredError": readonly ["请选择一个选项", "選択肢を選んでください", "Choose an option"];
    readonly "selection.remove": readonly ["移除{label}", "{label}を削除", "Remove {label}"];
    readonly "selection.addMore": readonly ["继续添加…", "さらに追加…", "Add more…"];
    readonly "selection.clear": readonly ["清除{label}", "{label}をクリア", "Clear {label}"];
    readonly "selection.value": readonly ["选择项", "選択項目", "Selection"];
    readonly "selection.minQuery": readonly ["输入至少 {count} 个字符开始搜索", "{count}文字以上入力して検索", "Type at least {count} characters to search"];
    readonly "selection.loading": readonly ["正在搜索…", "検索中…", "Searching…"];
    readonly "selection.failed": readonly ["搜索失败，请重试", "検索できませんでした。再試行してください", "Search failed. Please retry"];
    readonly "selection.results": readonly ["{count} 个候选项", "{count}件の候補", "{count} options"];
    readonly "selection.noResults": readonly ["没有匹配项，试试其他关键词", "一致する候補がありません。別の語句を試してください", "No matching options. Try another query"];
    readonly "selection.retryKey": readonly ["也可以按 Enter 重试", "Enterキーでも再試行できます", "You can also press Enter to retry"];
    readonly "selection.limit": readonly ["最多选择 {count} 项", "最大{count}件まで選択できます", "Select up to {count} options"];
    readonly "selection.selectedCount": readonly ["已选择 {count} 项", "{count}件選択済み", "{count} selected"];
    readonly "selection.dismissHint": readonly ["Esc 关闭", "Escで閉じる", "Esc to close"];
    readonly "selection.searchPlaceholder": readonly ["输入以搜索…", "入力して検索…", "Type to search…"];
    readonly "selection.choosePlaceholder": readonly ["请选择…", "選択してください…", "Choose an option…"];
    readonly "common.retry": readonly ["重试", "再試行", "Retry"];
};
