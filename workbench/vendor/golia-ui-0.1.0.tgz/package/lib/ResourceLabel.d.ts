import { type ReactNode } from 'react';
/** One row layout for production and design-preview resource names and counts. */
export declare function ResourceLabel({ marker, children, meta }: {
    marker: ReactNode;
    children: string;
    meta?: string;
}): import("react").JSX.Element;
