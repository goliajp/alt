import type { SVGProps } from 'react';
/** A fixed square viewport and track; only the arc rotates around the exact circle center. */
export declare function Spinner({ size, className, ...props }: SVGProps<SVGSVGElement> & {
    size?: number;
}): import("react").JSX.Element;
