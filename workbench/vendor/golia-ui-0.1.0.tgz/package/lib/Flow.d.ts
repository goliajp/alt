import { type ReactNode } from 'react';
export type FlowStepStatus = 'pending' | 'current' | 'complete' | 'busy' | 'error' | 'blocked' | 'skipped';
export type FlowAction = {
    label: string;
    onClick: () => void;
    disabled?: boolean;
    busy?: boolean;
};
/** The parent owns one size and one inset for the entire action row. */
export declare function FlowActions({ back, next, size, summary, placement }: {
    back?: FlowAction;
    next: FlowAction;
    size?: 'regular' | 'large';
    summary?: ReactNode;
    placement?: 'page' | 'dialog';
}): import("react").JSX.Element;
export type FlowStep = {
    id: string;
    label: string;
    description?: string;
    status?: FlowStepStatus;
    optional?: boolean;
    disabled?: boolean;
    panelId?: string;
};
export declare function StepMark({ status, number }: {
    status: FlowStepStatus;
    number: number;
}): import("react").JSX.Element;
/** Completed/skipped states are explicit; previous positions are never assumed complete. */
export declare function FlowSteps({ label, steps, current, canGo, onGo, orientation, statusLabels, optionalLabel }: {
    label: string;
    steps: readonly FlowStep[];
    current: string;
    canGo: (step: string) => boolean;
    onGo: (step: string) => void;
    orientation?: 'horizontal' | 'vertical';
    statusLabels: Record<FlowStepStatus, string>;
    optionalLabel: string;
}): import("react").JSX.Element;
/** One fixed body track and one shared footer: step changes cannot move the action rail. */
export declare function FlowFrame({ title, description, feedback, children, asideTitle, asideDescription, asideBanner, aside, actions, stepKey, state, panelId, navigation }: {
    title: string;
    description?: string;
    feedback?: ReactNode;
    children: ReactNode;
    asideTitle?: string;
    asideDescription?: string;
    asideBanner?: ReactNode;
    aside?: ReactNode;
    actions: ReactNode;
    stepKey: string;
    state?: string;
    panelId?: string;
    navigation?: ReactNode;
}): import("react").JSX.Element;
