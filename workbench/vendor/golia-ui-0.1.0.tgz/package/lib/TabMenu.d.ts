export declare function TabMenu({ locale, target, keys, dismiss, run }: {
    locale: 'en' | 'zh' | 'ja';
    target: {
        key: string;
        x: number;
        y: number;
    };
    keys: string[];
    dismiss: (restoreFocus?: boolean) => void;
    run: (keys: string[]) => void;
}): import("react").JSX.Element;
