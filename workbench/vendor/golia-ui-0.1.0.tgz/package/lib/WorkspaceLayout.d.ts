import type { ReactNode } from "react";
export declare function WorkspaceLayout({ scope, workbench, sidebar, toolbar, children, className }: {
    className?: string;
    scope?: "studio" | "website" | "product";
    workbench?: boolean;
    sidebar: ReactNode;
    toolbar: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
