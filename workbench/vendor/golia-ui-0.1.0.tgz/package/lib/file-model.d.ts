export declare const fileIdentity: (file: File) => string;
export declare function acceptsFile(file: Pick<File, 'name' | 'type'>, accept?: string): boolean;
export declare function selectFiles(current: readonly File[], incoming: readonly File[], { accept, multiple, maxFiles, maxFileSize }?: {
    accept?: string;
    multiple?: boolean;
    maxFiles?: number;
    maxFileSize?: number;
}): {
    files: File[];
    added: File[];
    rejected: {
        file: File;
        reason: "type" | "size" | "count" | "duplicate";
    }[];
};
