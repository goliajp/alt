import { type ButtonHTMLAttributes, type ComponentPropsWithRef, type TextareaHTMLAttributes, type ReactNode } from "react";
/** Shared interaction primitive for buttons, selectable rows and chart controls.
 * Composed controls own their layout; focus, disabled and form semantics live here.
 */
export declare function Action({ onClick, className, ...props }: ComponentPropsWithRef<'button'>): import("react").JSX.Element;
export declare function Button({ variant, busy, small, size, children, className, disabled, onClick, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "primary" | "secondary" | "ghost" | "danger";
    busy?: boolean;
    small?: boolean;
    size?: 'small' | 'regular' | 'large';
}): import("react").JSX.Element;
export declare function Field(props: {
    label: ReactNode;
    hint?: ReactNode;
    error?: string;
    reserveMessage?: boolean;
    required?: boolean;
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
export declare function Input(props: ComponentPropsWithRef<'input'>): import("react").JSX.Element;
/** Native selection retains browser keyboard support within the shared control skin. */
export declare function NativeSelect({ className, ...props }: ComponentPropsWithRef<'select'>): import("react").JSX.Element;
/** Five text rows by default; a one-row textarea shares the input's text geometry. */
export declare function Textarea({ rows, className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>): import("react").JSX.Element;
/** A row owns control sizing; small standalone actions join the row's rhythm. */
export declare function ControlRow({ children, size, layout, className, }: {
    children: ReactNode;
    size?: "regular" | "small";
    layout?: "fill" | "content";
    className?: string;
}): import("react").JSX.Element;
export declare function Badge({ children, tone, }: {
    children: ReactNode;
    tone?: "neutral" | "success" | "warning" | "danger" | "info" | "accent";
}): import("react").JSX.Element;
