import type { ReactNode } from "react";
export declare function Metric({ label, value, note, }: {
    label: string;
    value: ReactNode;
    note?: string;
}): import("react").JSX.Element;
