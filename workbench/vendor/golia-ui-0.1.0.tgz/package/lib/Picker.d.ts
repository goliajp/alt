import { type AriaAttributes } from 'react';
import { type OptionLoader, type SelectionOption, type SelectionOptionInput } from './selection-model.js';
type PickerCommon = AriaAttributes & {
    locale: "en" | "zh" | "ja";
    label?: string;
    id?: string;
    name?: string;
    options?: readonly SelectionOptionInput[];
    selectedOptions?: readonly SelectionOption[];
    loadOptions?: OptionLoader;
    debounceMs?: number;
    minQueryLength?: number;
    searchable?: boolean;
    clearable?: boolean;
    placeholder?: string;
    hint?: string;
    error?: string;
    reserveMessage?: boolean;
    disabled?: boolean;
    required?: boolean;
    className?: string;
    maxSelected?: number;
};
export type SinglePickerProps = PickerCommon & {
    value: string;
    onChange: (value: string, option?: SelectionOption) => void;
};
export type MultiPickerProps = PickerCommon & {
    value: readonly string[];
    onChange: (value: string[], options: SelectionOption[]) => void;
};
export declare function Picker(props: (SinglePickerProps & {
    multiple: false;
}) | (MultiPickerProps & {
    multiple: true;
})): import("react").JSX.Element;
export {};
