type Translate = (key: string, params?: Record<string, string | number>) => string;
export type FileInputProps = {
    t: Translate;
    number: (value: number, digits?: number) => string;
    active?: boolean;
    onFiles?: (added: File[]) => void;
    onChange?: (files: File[]) => void;
    accept?: string;
    disabled?: boolean;
    multiple?: boolean;
    maxFiles?: number;
    maxFileSize?: number;
    preview?: boolean;
};
export declare function FileInput({ t, number, active, onFiles, onChange, accept, disabled, multiple, maxFiles, maxFileSize, preview }: FileInputProps): import("react").JSX.Element;
export {};
