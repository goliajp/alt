import { type ReactNode } from 'react';
export type WorkbenchLabels = {
    title: string;
    explorer: string;
    inspector: string;
    activity: string;
    toggleExplorer: string;
    toggleInspector: string;
    toggleActivity: string;
    reset: string;
    close: string;
    resize: (name: string) => string;
};
/** Shared workspace furniture. Product adapters supply real resources and documents. */
export declare function WorkbenchLayout({ storageKey, routeKey, labels, toolbar, explorer, inspector, tabs, activity, status, children, className }: {
    storageKey: string;
    routeKey: string;
    labels: WorkbenchLabels;
    toolbar: ReactNode;
    explorer: ReactNode;
    inspector: ReactNode;
    tabs: ReactNode;
    activity: ReactNode | ((close: () => void) => ReactNode);
    status?: ReactNode;
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
