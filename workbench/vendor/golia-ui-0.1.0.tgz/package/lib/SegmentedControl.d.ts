import { type SelectionOptionInput } from "./selection-model.js";
type GroupProps = {
    label: string;
    options: readonly SelectionOptionInput[];
    hint?: string;
    error?: string;
    reserveMessage?: boolean;
    name?: string;
    disabled?: boolean;
    required?: boolean;
    className?: string;
};
type SingleGroupProps = GroupProps & {
    value: string;
    onChange: (value: string) => void;
};
export declare function SegmentedControl({ label, options, value, onChange, hint, error, reserveMessage, name, disabled, required, className, hideLabel, }: SingleGroupProps & {
    hideLabel?: boolean;
}): import("react").JSX.Element;
export {};
