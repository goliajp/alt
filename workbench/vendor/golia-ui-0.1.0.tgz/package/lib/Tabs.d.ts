import { type ReactNode } from "react";
export declare function Tabs({ items, value, onChange, children, variant, label, }: {
    items: readonly (readonly [string, string])[];
    value: string;
    onChange: (v: string) => void;
    children?: ReactNode;
    variant?: "segmented" | "line";
    label?: string;
}): import("react").JSX.Element;
