import type { ReactNode } from "react";
/** Validation replaces help in one reserved slot instead of moving the next control. */
export declare function FieldFeedback({ id, hint, error, reserveSpace }: {
    id: string;
    hint?: ReactNode;
    error?: string;
    reserveSpace?: boolean;
}): import("react").JSX.Element | null;
