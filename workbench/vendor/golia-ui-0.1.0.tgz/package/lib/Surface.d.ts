import type { ReactNode } from "react";
export declare function Heading({ title, description, action, level, }: {
    title: string;
    description?: string;
    action?: ReactNode;
    level?: 1 | 2;
}): import("react").JSX.Element;
export declare function Surface({ title, action, footer, children, className, body, appearance, dividers, }: {
    title?: string;
    action?: ReactNode;
    footer?: ReactNode;
    children: ReactNode;
    className?: string;
    body?: boolean;
    appearance?: "outlined" | "tonal" | "plain";
    dividers?: "auto" | "always" | "none";
}): import("react").JSX.Element;
