export type TabCloseAction = 'close' | 'others' | 'left' | 'right' | 'all';
export declare function tabCloseTargets(keys: string[], key: string, action: TabCloseAction): string[];
