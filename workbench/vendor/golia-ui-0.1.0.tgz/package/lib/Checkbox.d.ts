import { type InputHTMLAttributes, type ReactNode } from 'react';
type CheckboxInputProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type' | 'checked'> & {
    checked: boolean | 'mixed';
};
/** Keep native form/keyboard semantics, with one shared checked/mixed style. */
export declare function CheckboxInput({ checked, ...props }: CheckboxInputProps): import("react").JSX.Element;
export declare function Checkbox({ label, onChange, className, ...props }: Omit<CheckboxInputProps, 'onChange'> & {
    label: ReactNode;
    onChange: (checked: boolean) => void;
}): import("react").JSX.Element;
export declare function Radio({ label, className, ...props }: Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & {
    label: ReactNode;
}): import("react").JSX.Element;
export {};
