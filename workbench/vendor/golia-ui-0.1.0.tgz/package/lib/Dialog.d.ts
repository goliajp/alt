import { type ReactNode } from "react";
export declare function Dialog({ open, onClose, title, children, footer, drawer, active, closeLabel, }: {
    open: boolean;
    onClose: () => void;
    title: string;
    children: ReactNode;
    footer?: ReactNode;
    drawer?: boolean;
    active?: boolean;
    closeLabel: string;
}): import("react").JSX.Element;
