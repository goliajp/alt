import { type HTMLAttributes, type ReactElement } from 'react';
/** A portal keeps rail hints visible outside the rail's scrolling/clipping box. */
export declare function Tooltip({ label, children }: {
    label: string;
    children: ReactElement<HTMLAttributes<HTMLElement>>;
}): import("react").JSX.Element;
