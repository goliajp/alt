# @golia/ui

Versioned React controls, theme tokens, document tabs and workbench furniture shared by GOLIA products. Product adapters supply identity, resources, documents, permissions and translated labels.

This package ships JavaScript modules, TypeScript declarations and the complete original TypeScript/TSX and CSS sources. React, React DOM and Lucide are peer dependencies. It has no account service, product store, demo fixture, network client or brand asset dependency. Run `npm run build` in the unpacked package with its declared development dependencies to rebuild the modules. Import individual exports, for example `@golia/ui/controls`, `@golia/ui/WorkbenchLayout` and `@golia/ui/tokens.css`. Import each stylesheet needed by the selected controls; styles are never injected automatically.

The canonical source is this package directory. `ORIGIN.json` records the extraction input; it is provenance, not a substitute for the package integrity recorded by a consumer lockfile. Both products consume a versioned package. An offline release may vendor the unmodified npm tarball with its digest and licenses. Changes are made here, versioned, checked in both consumers, and then packaged; consumers do not fork components.

Accessibility, focus handling, keyboard navigation, light/dark tokens and reduced motion behavior remain shared. Layout storage contains panel geometry only; the application supplies a scoped storage key and must remount the layout when its owner changes. Authentication, resource authorization and document ownership remain the application's responsibility.
